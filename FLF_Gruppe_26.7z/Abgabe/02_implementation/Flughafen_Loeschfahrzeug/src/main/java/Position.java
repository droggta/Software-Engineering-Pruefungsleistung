public enum Position {
    frontLeft,
    frontRight,
    frontRoof,
    backLeft,
    backRight,
    frontRoofLeft,
    frontRoofRight,
    backRoofLeft,
    backRoofRight,
    left,
    right,
    outdoor,
    indoor
}
