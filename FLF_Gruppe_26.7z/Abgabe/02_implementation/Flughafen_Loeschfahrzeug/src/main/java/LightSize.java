public enum LightSize {
    small,
    medium,
    big
}
