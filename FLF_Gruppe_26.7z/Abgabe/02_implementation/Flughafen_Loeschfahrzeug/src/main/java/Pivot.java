public abstract class Pivot {

    private Position position;

    public void setaWheel(Wheel[] aWheel) {
    }

}
