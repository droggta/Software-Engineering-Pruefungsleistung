public class SpeedDisplay extends Display{


    public SpeedDisplay() {

    }

    @Override
    public void setValue(int aVelocity) {
        displayedValue = aVelocity;
    }
}
