public class BreakDisc {

    public BreakDisc() {

    }

}
