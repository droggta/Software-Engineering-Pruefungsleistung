public enum BatteryStatus {
    load,
    use,
    idle
}
