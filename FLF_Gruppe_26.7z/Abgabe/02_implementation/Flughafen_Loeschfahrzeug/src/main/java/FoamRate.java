public enum FoamRate {
    zero,
    drei,
    fuenf,
    zehn
}
