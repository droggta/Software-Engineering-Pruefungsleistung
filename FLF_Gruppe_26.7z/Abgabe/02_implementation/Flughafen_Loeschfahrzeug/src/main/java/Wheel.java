public class Wheel {

    public void setaBreakDisc(BreakDisc[] aBreakDisc) {
    }

    public Wheel() {

    }

}
