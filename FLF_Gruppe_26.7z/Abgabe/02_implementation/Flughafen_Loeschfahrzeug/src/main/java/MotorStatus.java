public enum MotorStatus {
    on,
    off
}
