public enum LEDColor {
    blue,
    orange,
    literal
}
