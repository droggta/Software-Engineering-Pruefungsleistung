public enum CannonSteps {
    fuenfhundert,
    tausend,
    tausendfuenfhundert,
    zweitausend,
    zweitausendfuenfhundert,
    dreitausend,
    dreitausendfuenfhundert
}
