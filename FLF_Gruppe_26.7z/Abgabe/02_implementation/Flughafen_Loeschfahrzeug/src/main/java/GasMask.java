public class GasMask {

    public GasMask() {

    }

}
