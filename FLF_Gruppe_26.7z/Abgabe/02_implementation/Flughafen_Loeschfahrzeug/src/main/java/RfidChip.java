public class RfidChip {
    private String aEncryptedString;

    public String getaEncryptedString() {
        return aEncryptedString;
    }

    public void setaEncryptedString(String aEncryptedString) {
        
        this.aEncryptedString = aEncryptedString;
    }
}


