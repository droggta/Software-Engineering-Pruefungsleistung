public interface Pedal {
    void changeSpeedStep();
}
