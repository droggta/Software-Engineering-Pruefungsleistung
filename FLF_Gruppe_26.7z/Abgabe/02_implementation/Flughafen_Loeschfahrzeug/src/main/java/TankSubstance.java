public enum TankSubstance {
    water,
    foam
}
