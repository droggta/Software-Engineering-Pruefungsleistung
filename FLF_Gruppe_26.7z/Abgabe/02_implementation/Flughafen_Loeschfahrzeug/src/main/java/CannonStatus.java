public enum CannonStatus {
    retracted,
    extended,
    activated,
    deactivated
}
