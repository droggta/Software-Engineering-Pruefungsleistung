public enum DoorStatus {
    open,
    closed,
    locked
}
