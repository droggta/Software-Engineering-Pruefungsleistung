public enum ButtonStatus {
    active,
    inactiv
}
