public class LED {

    public LED() {

    }

}
