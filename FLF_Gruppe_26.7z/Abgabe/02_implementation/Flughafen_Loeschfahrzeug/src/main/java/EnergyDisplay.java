public class EnergyDisplay extends Display{

    public EnergyDisplay() {

    }

}
