public enum SwitchType {
    electricEngines,
    warningLight,
    blueLight,
    headLamp,
    roofMountedLight,
    sideLamp
}
