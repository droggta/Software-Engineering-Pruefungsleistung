public enum LightStatus {
    on,
    off
}
