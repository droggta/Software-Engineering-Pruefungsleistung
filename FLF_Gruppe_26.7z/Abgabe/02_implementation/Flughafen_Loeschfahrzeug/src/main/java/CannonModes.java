public enum CannonModes {
    modeA,
    modeB,
    modeC
}
