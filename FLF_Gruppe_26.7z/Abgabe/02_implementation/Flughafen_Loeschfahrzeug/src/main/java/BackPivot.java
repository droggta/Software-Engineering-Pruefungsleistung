public class BackPivot extends Pivot{

    public BackPivot() {

    }

}
