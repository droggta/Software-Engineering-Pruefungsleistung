public class PieceSegment {

    final int length;


    public PieceSegment(int plength){
        length = 0;

    }
}
