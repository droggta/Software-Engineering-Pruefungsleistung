public enum SwitchStatus {
    on,
    off
}
